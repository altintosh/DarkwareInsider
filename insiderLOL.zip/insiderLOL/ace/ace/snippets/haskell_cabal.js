ace.define("ace/snippets/haskell_cabal",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "haskell_cabal";

});                (function() {
                    ace.require(["ace/snippets/haskell_cabal"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            